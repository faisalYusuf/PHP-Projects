-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 23, 2020 at 07:47 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `thesis_book`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `ID` int(11) NOT NULL,
  `Firstname` varchar(33) NOT NULL,
  `Lastname` varchar(33) NOT NULL,
  `Phone` varchar(33) NOT NULL,
  `Email` varchar(33) NOT NULL,
  `Password` varchar(33) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`ID`, `Firstname`, `Lastname`, `Phone`, `Email`, `Password`) VALUES
(12, 'ahmed', 'mohamed', '1234', 'ahmed@gmail.com', '1234'),
(13, 'hamda', 'mohamed', '789', 'hamda@mail.com', '1234'),
(14, 'hamda', 'saed', '4566782', 'hamda@gmail.com', '2233'),
(15, '', 'cawaale', '8989', 'saad@gmail.com', '333'),
(16, '', 'cawalae', '0634968483', 'faisal@gmail.com', '1122'),
(17, 'samaale', 'faarax', '6767', 'faarax@gmail.com', '5676'),
(18, 'samaale', 'faarax', '6767', 'faarax@gmail.com', '5676'),
(19, 'kurey', 'waalan', '6789', 'falis@gmail.com', '6666'),
(20, 'faisal', 'khaalid', '77787', 'faisall@gmail.com', '3344'),
(21, 'faisal', 'khaalid', '77787', 'faisall@gmail.com', '34455'),
(22, 'faisal', 'khaalid', '77787', 'faisall@gmail.com', '2323'),
(23, 'faisall', 'khaalid', '77787', 'faisall@gmail.com', '5454'),
(24, 'faysaluu', 'mohamed', '77787', 'faisall@gmail.com', '3455'),
(25, 'faisall', 'samaale', '77787', 'faisall@gmail.com', '4444'),
(26, 'faysaluu', 'khaalid', '77787', 'faisall@gmail.com', '2323'),
(32, 'faysaluu', 'khaalidd', '7688', 'khaalidf@gmail.com', '2323'),
(35, 'faysaly', 'khaalid', '7688', 'khaalid@gmail.com', '778'),
(36, 'faysaluu', 'khaalid', '7688', 'khaalid@gmail.com', '8787'),
(37, 'cawaale', 'khaalid', '434', 'khaalidz@gmail.com', '23232'),
(49, 'fg', 'ju', '8888898989898', 'kijluu@gmail.com', '74637383736'),
(50, 'fg', 'ju', '8888898989898', 'fasal@gmail.com', '4567656777'),
(51, 'maxamed', 'jaamac', '34343423232323', 'nasra@gmail.com', '123456789'),
(52, 'nasrin', 'mohs', '8787878878', 'rafiiq@gmail.com', '123456789'),
(53, 'hamda', 'ahmed', '78786544356', 'hamdasaed@gmail.com', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `kitchen`
--

CREATE TABLE `kitchen` (
  `ID` int(11) NOT NULL,
  `Name` varchar(33) NOT NULL,
  `Image` blob NOT NULL,
  `Discription` varchar(33) NOT NULL,
  `Quantity` int(20) NOT NULL,
  `Price` int(20) NOT NULL,
  `Status` int(11) NOT NULL,
  `User_ID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kitchen`
--

INSERT INTO `kitchen` (`ID`, `Name`, `Image`, `Discription`, `Quantity`, `Price`, `Status`, `User_ID`) VALUES
(4, 'kudrad', 0x636c69656e742e504e47, 'mawacna ', 5, 5, 1, 1),
(11, 'shaah', 0x64617461626173652064657369676e2e504e47, 'lamahyo', 3, 2, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `Order_Number` int(11) NOT NULL,
  `Customer_ID` int(11) NOT NULL,
  `Delivery_Price` int(11) NOT NULL,
  `Order_Date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`Order_Number`, `Customer_ID`, `Delivery_Price`, `Order_Date`) VALUES
(1, 53, 2147483647, '0000-00-00 00:00:00.000000'),
(2, 53, 2147483647, '0000-00-00 00:00:00.000000'),
(3, 53, 2147483647, '0000-00-00 00:00:00.000000'),
(4, 53, 2147483647, '0000-00-00 00:00:00.000000'),
(5, 53, 2147483647, '0000-00-00 00:00:00.000000'),
(8, 53, 2147483647, '0000-00-00 00:00:00.000000'),
(9, 53, 2147483647, '0000-00-00 00:00:00.000000');

-- --------------------------------------------------------

--
-- Table structure for table `order_details`
--

CREATE TABLE `order_details` (
  `Order_Number` int(11) NOT NULL,
  `Kitchen_ID` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Order_Date` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_details`
--

INSERT INTO `order_details` (`Order_Number`, `Kitchen_ID`, `Quantity`, `Total`, `Order_Date`) VALUES
(3, 4, 1, 8, '2020-09-07 12:13:12.338040'),
(4, 4, 1, 8, '2020-09-07 12:49:11.740604'),
(5, 11, 5, 13, '2020-09-07 12:52:06.972552'),
(8, 11, 1, 5, '2020-09-07 12:56:08.720568'),
(9, 4, 1, 8, '2020-09-07 13:24:19.776237');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `kitchen`
--
ALTER TABLE `kitchen`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `User_ID` (`User_ID`),
  ADD KEY `User_ID_2` (`User_ID`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`Order_Number`),
  ADD KEY `Customer_ID` (`Customer_ID`);

--
-- Indexes for table `order_details`
--
ALTER TABLE `order_details`
  ADD PRIMARY KEY (`Order_Number`),
  ADD KEY `Order_ID` (`Order_Number`,`Kitchen_ID`),
  ADD KEY `Kitchen_ID` (`Kitchen_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT for table `kitchen`
--
ALTER TABLE `kitchen`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `Order_Number` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `kitchen`
--
ALTER TABLE `kitchen`
  ADD CONSTRAINT `kitchen_ibfk_1` FOREIGN KEY (`User_ID`) REFERENCES `users` (`ID`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`Customer_ID`) REFERENCES `customers` (`ID`);

--
-- Constraints for table `order_details`
--
ALTER TABLE `order_details`
  ADD CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`Kitchen_ID`) REFERENCES `kitchen` (`ID`),
  ADD CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`Order_Number`) REFERENCES `orders` (`Order_Number`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
