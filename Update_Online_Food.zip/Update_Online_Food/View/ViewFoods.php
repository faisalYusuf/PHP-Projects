<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A-d-M-n-P</title>
    
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">

</head>
<body>

<?php  

    include "../Modal/Food.class.php";
    $Food = new Food();
    $fetch_Data_kitchen = $Food->fetch_Data_kitchen();

?>

<div class="container-fluid fixed-top ">
    <div class="row">
        <div class="col-10  top-header  ">

        <nav class="navbar navbar-expand-sm ">
            <!-- Brand -->
            <a class="navbar-brand" href="../admin/Dashboard.php">ADMIN PANEL</a>

            <!-- Links -->
            <ul class="navbar-nav ml-auto">
                <!-- Dropdown -->
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbardrop" data-toggle="dropdown">
                  <i class="fas fa-user fa-1x"></i> Profile
                </a>
                <div class="dropdown-menu down-menu">
                    <a class="dropdown-item" href="#">Link 1</a>
                    <a class="dropdown-item" href="#">Link 2</a>
                    <a class="dropdown-item" href="#">Link 3</a>
                </div>
                </li>
           </ul>
        </nav>

        </div><!-- End of col-->
    </div><!-- End of row-->
</div><!-- End of container-->


    <!-- ANother Row -->
    <div class="container-fluid align-container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidenav">

                     <div class="text-center text-light mb-5 ">
                        <i class="fas fa-user fa-2x"></i>
                        <h5 class="text-capitalize">my account</h5>
                     </div>
                    
                    
                     <a href="../admin/Dashboard.php" class="">&nbsp; &nbsp;<i class="fas fa-home  manage-icon active  text-primary"></i>home</a>
                    <button class="dropdown-btn"><i class="fas fa-user-friends  manage-icon text-primary"></i>Foods
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../Controller/AddFoods.php">Add Food</a>
                        <a href="../View/ViewFoods.php">List Foods</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-chess-rook  manage-icon text-primary"></i>&nbsp;&nbsp;Users 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container"><i class=""></i>
                        <a href="../Controller/AddUsers.php">Add Users</a>
                        <a href="../View/viewUsers.php">Manage Users</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Orders 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewOrders.php">View Orders</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Customer
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewCustomers.php">List Customers</a>
                    </div>

               </div>
          </div>

          <!-- content you write any thing to show the user  -->
      
            <div class="col-md-9 content">

                <div class="row">
                  <div class="col-lg-12 mx-auto ">
                    <div class="form-group">
                    <div class="card text-dark card-transparent">
                       <div class="card-header text-uppercase text-light">Foods</div>
                       <div class="card-body text-light">

                       <table class="table text-light striped">
                            <thead>
                                <th>image</th>
                                <th>Name</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Edit</th>
                                <th>Delete</th>
                            </thead>

                            <tbody>
                                <?php if($fetch_Data_kitchen) {
                                foreach ($fetch_Data_kitchen as $row) { ?>
                                    
                                <tr>
                                <td><img  src="../Upload_Images/<?php echo $row['Image'] ;?>" class="img-fluid" 
                                    style="width:80px; height:50px" > </td>
                                <td><?php echo $row['Name'] ?></td>
                                <td><?php echo $row['Quantity'] ?></td>
                                <td><?php echo $row['Price'] ?></td>
                                <td>
                                    <a href="../Controller/EditFoods.php?idfood=<?php echo $row['ID']?>" class="btn btn-info">Edit</a>
                                </td>
                                <td>
                                    <a href="../Controller/Delete.php?idfood=<?php echo $row['ID']?>" class="btn btn-danger">Delete</a>
                                </td>
                                </tr>
                                <?php }} ?>
                            </tbody>
                      </table>


                    </div><!-- End OF card body -->
                   </div><!-- End OF card -->
                 </div><!-- End of form group -->
                </div><!-- End of col -->
            </div>
        </div><!-- End of row -->

    </div> <!-- End OF Content -->






<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>
</body>
</html>