<?php 

    
class Connection{

    private $host = "localhost";
    private $user = "root";
    private $pass = "";
    private $db = "thesis_book"; 
    public  $conn;

    public function __construct(){

        $this->conn = new  mysqli($this->host ,$this->user ,$this->pass ,$this->db);
    }
    
}


?>