
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online food oredering  System</title>

    <!-- magnific popup css -->
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <!-- google fonts you can add your file any font  -->
    
</head>
<body>
<?php

    session_start();
    $ID = $_SESSION['ID'];
    if(isset($_SESSION['Email'])){

    }

    else{
        header("location: ../Controller/sign_in.php");
    }

    include "../Modal/Search.php";
    $Search = new Search();
    $Fetch_Data_search = $Search->fetch_Data_Search();
    

?>

<!-- Section Nav -->
<nav class="navbar  nav navbar-expand-md sticky-top change-bg-nav">
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav">
         <span class="text-light" ><i class="fas fa-tasks"></i></span>
      </button>

      <div class="collapse navbar-collapse" id="mynav">
          
          <ul class="navbar-nav">
          <li class="nav-item">
                <a href="../Public/Customerpage.php" class="nav-link">Home</a>
            </li>
         </ul>
           <ul class="navbar-nav ml-auto">
           <li class="nav-item">
          <a href="../Public/orderhistory.php" class="nav-link">Your Order</a>
          </li>
          <li class="nav-item">
          <a href="../Controller/logout.php?idcustomer=<?php echo $ID; ?>" class="nav-link">Logout</a>
          </li>
          </ul>
         
         
      </div>
</nav>

<!-- title  Header  -->

<header id="header" class="main-headertwo">
    <div class="container">
        <div class="row ">
            <div class="col-md-9 mx-auto">
                <div class="bannertwo text-center mt-5">
                    <h4 class="text-capitalize ">
                        <small class="text-light" >Great food and</small><strong class="text-danger"> high quality of services</strong>
                    </h4>
                    <!-- <a href="#" class="btn maintwo-btn text-capitalize">Order onLine</a> -->
                </div>
            </div>
        </div>
    </div>
</header>
<!-- End title header -->


<!-- Section Food items   -->
 
<section id="pricing" class="my-2 py-5" >
  <div class="container">

    <div class="row">
        <div class="col-md-8 mx-auto text-center   ">
            <h4 class="text-uppercase font-weight-bold">Order Summery</h4>
        </div>
    </div>
    
    <div class="row mt-4">

        <div class="col-md-12 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-center text-uppercase text-light"></h2>
                </div><!-- End Of  header-->

                <div class="card-body">
                    <div>
                    <table id="example" class="table text-dark striped">
                             <thead>
                                <th>Firstnane</th>
                                <th>Lastname</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Order_Date</th>
                                
                            </thead>

                            <tbody>
                                <?php if($Fetch_Data_search) {
                                foreach ($Fetch_Data_search as $row) { ?>
                                    
                                <tr>
                                <td><?php echo $row['Firstname'] ?></td>
                                <td><?php echo $row['Lastname'] ?></td>
                                <td><?php echo $row['Quantity'] ?></td>
                                <td><?php echo $row['Total'] ?></td>
                                <td><?php echo $row['Order_Date'] ?></td>
                                    
                                <td>
                                    <!-- <a href="OrderPage.php?idfood=<?php //echo $row['ID']?> & idcustomer=<?php //echo $ID ?>" class="btn btn-info"></a> -->
                                </td>
                                </tr>
                                <?php }} ?>
                            </tbody>
                        </table>

                    </div><!-- End Of d-flex -->
                </div><!-- End Of  body -->

            </div><!-- End Of  card -->
        </div><!-- End Of  col-md-6 -->

    </div><!-- End Of  row -->
  </div><!-- End Of  container -->
</section><!-- End Of  section -->

<!--  ------------------------------ section about us  ------------------------>

<section id="about" class="aboutus">
    <div class="container">
        <div class="row">

            <div class="col-md-6 text-center mx-auto mt-4 text-light">
                <h3 class="text-capitalize font-weight-bold display-2">lets eat, </h3>
                <p class="lead">Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                  Cum magnam vitae et cumque quos explicabo animi accusamus laudantium minima! Tempora.</p>
                  <i class="fas fa-hands fa-3x"></i>
            </div><!-- End of col-3 -->
        
        </div><!-- End of row -->

         <div class="row">

            <div class="col-md-6 text-center mx-auto my-4 text-light">
                <h3 class="text-capitalize font-weight-bold">contact with us, </h3>
                 <div>
                     <div class="d-flex justify-content-around my-4">
                        <i class="fab fa-facebook fa-2x text-info"></i>
                        <i class="fab fa-youtube fa-2x text-danger"></i>
                        <i class="fab fa-google fa-2x text-warning"></i>
                        <i class="fab fa-twitter fa-2x text-primary"></i>
                     </div><!-- End of d-flex -->
                 </div>
            </div><!-- End of col-3 -->
            
        </div><!-- End of row -->

    </div><!-- End of container -->
</section><!-- End of  section our about -->


<!--  ------------------------------ section about us  ------------------------>

<section class="footer pt-3">
    <p class="text-capitalize text-light text-center">hilaal hotel Coffee &copy Copy right </p>
</section>


<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>


</body>
</html>