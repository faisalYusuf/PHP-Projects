
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restourant Management System</title>

    <!-- magnific popup css -->
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <!-- google fonts you can add your file any font  -->
    
</head>
<body>
<?php

    session_start();
    $ID = $_SESSION['ID'];
    if(isset($_SESSION['Email'])){

    }

    else{
        header("location: ../Controller/sign_in.php");
    }

    include "../Modal/Order.class.php";
    $Order = new Order();
    $fetch_Data_kitchen = $Order->fetch_Data_kitchen();
    if(isset($_GET['idcustomer'])){
        $idcustomer = $_GET['idcustomer'];
    }
            
       $idfood = $_GET['idfood'];
       $ShowOnlySelectedOrder = $Order->ShowOnlySelectedOrder($idfood);
       $Order = $Order->AddOrder();
    
?>

<!-- Section Nav -->
<nav class="navbar  nav navbar-expand-md sticky-top change-bg-nav">
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav">
         <span class="text-light" ><i class="fas fa-tasks"></i></span>
      </button>

      <div class="collapse navbar-collapse" id="mynav">
      <ul class="navbar-nav ml-auto">
          <li class="nav-item">
          <a href="../Controller/logout.php?idcustomer=<?php echo $ID; ?>" class="nav-link">Logout</a>
            </li>
        
          </ul>
      </div>
</nav>


<!-- title  Header  -->

<header id="header" class="main-headertwo">
    <div class="container">
        <div class="row ">
            <div class="col-md-9 mx-auto">
                <div class="bannertwo text-center mt-5">
                    <h4 class="text-capitalize ">
                        <small class="text-light" >Great food and</small><strong class="text-danger"> high quality of services</strong>
                    </h4>
                    <a href="#" class="btn maintwo-btn text-capitalize">Order onLine</a>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- End title header -->


<!-- Section Food items   -->
 
<section id="pricing" class="my-2 py-5" >
  <div class="container">

    <div class="row">
        <div class="col-md-8 mx-auto text-center   ">
            <h4 class="text-uppercase font-weight-bold">Available foods</h4>
             <p class="lead text-secondary text-capitalize ml-4"> dates indicate how long food will remain of good quality – 
                 food is still safe to eat after this date.</p>
        </div>
    </div>
    
    <div class="row mt-4">

        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-center text-uppercase text-light"></h2>
                </div><!-- End Of  header-->

                <div class="card-body">
                    <div>
                        <table class="table text-dark striped">
                            <thead>
                                <th>image</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Status</th>
                            </thead>

                            <tbody>
                            <?php foreach ($fetch_Data_kitchen as $row) { ?>
                                    <?php if($row['Status'] == 1){?>
                                <tr>
                                <td><img  src="../Upload_Images/<?php echo $row['Image'] ;?>" class="img-fluid" 
                                    style="width:80px; height:50px" > </td>
                                <td><?php echo $row['Name'] ?></td>
                                <td><?php echo $row['Price'] ?></td>
                                <td>
                                    <a href="OrderPage.php?idfood=<?php echo $row['ID']?> & idcustomer=<?php echo $ID ?>" class="btn btn-info">Order</a>
                                </td>
                                </tr>
                                <?php } if($row['Status'] == 0){ ?>
                                <?php }}?>
                            </tbody>
                        </table>

                    </div><!-- End Of d-flex -->
                </div><!-- End Of  body -->

            </div><!-- End Of  card -->
        </div><!-- End Of  col-md-6 -->



        <div class="col-md-4">
            
           <div class="card">
               <div class="header"></div>

               <div class="card-body text-dark">
               <?php if($ShowOnlySelectedOrder){
                     foreach ($ShowOnlySelectedOrder as $row) {?>
                         <form action="" method="POST" enctype="multipart/form-data"> 
                            <img  src="../Upload_Images/<?php echo $row['Image'] ;?>" class="img-fluid d-flex mx-auto " 
                            style="width:150px; height:50px;" >&nbsp;
                            <h5 class="card-text ">Food Name : &nbsp;<?php echo $row['Name'] ?></h5>
                            <h5 class="card-text">Price : &nbsp;<?php echo $row['Price'] ?></h5>
                            <h5 class="card-text">Delivery : &nbsp; $2</h5>

                            <input type="hidden" name="DeliveryPrice" value="2">
                            <input type="hidden" name="total" value="<?php echo $row['Price'] ?>">
                            <input type="hidden" name="actions" value="Order_Food">
                            <input type="hidden" name="idFood" value="<?php echo $idfood;?>">
                            <input type="hidden" name="idcustomer" value="<?php echo $idcustomer; ?>"><br>
                            <h4 class="">Quantity</h4>
                            <input type="text" name="quantity"  class="form-control" min="1" value="1"><br>
                            
                            <?php 

                            if(!isset($_GET['signup'])){
                                
                            }else{
                                $signupcheck = $_GET['signup'];
                                
                                if($signupcheck == "num"){
                                    
                                    echo "<p class='error p'>Only numbers allowed </p>";
                                }
                                if($signupcheck == "select"){
                                    echo "<p class='error p'>Please select Type money </p>";
                                }
                                if($signupcheck == "quentity-min"){
                                    echo "<p class='error p'>Please Enter at least one number  </p>";
                                }
                            }
                            ?>
                            <select name="money" id="select" onchange="selected();" class="form-control my-2">
                                <option>-- select type money </option>
                                <option>Money_Type</option>
                                 <input type="hidden">
                                 <label for=""> E-Dahab</label>
                                <input type="text" id="textvalue1" readonly="" class="form-control">
                                <label for="">Zaad Service </label>
                                <input type="text" id="textvalue2" readonly="" class="form-control">
                                
                            </select>
                            <input type="submit" name="SendFood" value="Check Out" class="btn btn-dark btn-block">
                        </form>
                                    
                 <?php }}?>                
               </div><!-- End Of  card-body -->

           </div><!-- End Of  card-->
       </div><!-- End Of  col-md-6 -->


    </div><!-- End Of  row -->
  </div><!-- End Of  container -->
</section><!-- End Of  section -->


<!-- ------------------------------------------  ection Services  --------------------------------->

    
 <section id="services" class="pt-3">
        <div class="container">

            <div class="row">
                <div class="col-md-8 mx-auto text-center p-4">
                    <h3 class="text-uppercase font-weight-bold">our Services</h3>
                    <p class="lead">
                        Are you looking for a specific service or facility,<br>
                        free access to our beach, get free services like free breakfast, free wi-fi etc.
                    </p>
                </div>
            </div>

            <!-- Another Row -->
            <div class="row">

                <div class="col-md-4 text-center p-4 ">
                    <i class="fas fa-rocket text-info fa-3x"></i><br><br>
                  <p class="text-capitalize">
                    you can make order our food and we prepared us all dinners you want to delivery 
                  </p>
                </div><!-- End Of col   -->

                <div class="col-md-4 text-center p-4 ">
                   <i class="fas fa-coffee fa-3x text-warning"></i><br><br>
                  <p class="text-capitalize">
                    drink cup of coffee to get more energy and work with, to finish your dialy activities 
                  </p>
                </div><!-- End Of col   -->

                <div class="col-md-4 text-center p-4 ">
                 <i class="fas fa-taxi fa-3x text-danger"></i><br><br>
                  <p class="text-capitalize">
                    Delivered by using taxi and takes it what you deliverd it 
                  </p>
                </div><!-- End Of col   -->

            </div><!-- End Of row   -->
        </div><!-- End Of container   -->
    </section> <!-- End Of section services  -->




<!--  ------------------------------ section about us  ------------------------>

<section id="about" class="aboutus">
    <div class="container">
        <div class="row">

            <div class="col-md-6 text-center mx-auto mt-4 text-light">
                <h3 class="text-capitalize font-weight-bold display-2">lets eat, </h3>
                <p class="lead">Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                  Cum magnam vitae et cumque quos explicabo animi accusamus laudantium minima! Tempora.</p>
                  <i class="fas fa-hands fa-3x"></i>
            </div><!-- End of col-3 -->
        
        </div><!-- End of row -->

         <div class="row">

            <div class="col-md-6 text-center mx-auto my-4 text-light">
                <h3 class="text-capitalize font-weight-bold">contact with us, </h3>
                 <div>
                     <div class="d-flex justify-content-around my-4">
                        <i class="fab fa-facebook fa-2x text-info"></i>
                        <i class="fab fa-youtube fa-2x text-danger"></i>
                        <i class="fab fa-google fa-2x text-warning"></i>
                        <i class="fab fa-twitter fa-2x text-primary"></i>
                     </div><!-- End of d-flex -->
                 </div>
            </div><!-- End of col-3 -->
            
        </div><!-- End of row -->

    </div><!-- End of container -->
</section><!-- End of  section our about -->


<!--  ------------------------------ section about us  ------------------------>

<section class="footer pt-3">
    <p class="text-capitalize text-light text-center">hilaal hotel Coffee &copy Copy right </p>
</section>


<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>


</body>
</html>