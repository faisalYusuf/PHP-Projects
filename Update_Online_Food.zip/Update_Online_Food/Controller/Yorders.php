<?php

    include "admin/connection.php";

    session_start();
    $ID = $_SESSION['ID'];
    if(isset($_SESSION['Email'])){

    }

    else{
        header("location: sign_in.php");
    }

    // $idcustomer = $_GET['idcustomer'];
    $query = "SELECT customers.Firstname, customers.Lastname, orders.Order_Date, order_Details.Quantity,order_Details.Total 
    FROM customers
    INNER JOIN Orders ON orders.Customer_ID = customers.ID
    INNER JOIN order_Details ON Orders.Order_Number = order_Details.Order_Number WHERE ID = $ID";
    $result = mysqli_query($conn,$query);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restourant Management System</title>

    <!-- magnific popup css -->
    <link rel="stylesheet" href="css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="css/style.css">
     <!-- font awesome js all icons  -->
     <script src="js/all.js" ></script>
     <!-- google fonts you can add your file any font  -->
     <!-- <link href="https://fonts.googleapis.com/css?family=Knewave&display=swap" rel="stylesheet"> -->
</head>
<body>


<!-- Section Nav -->
<nav class="navbar  nav navbar-expand-md sticky-top change-bg-nav">
     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#mynav">
         <span class="text-light" ><i class="fas fa-tasks"></i></span>
      </button>

      <div class="collapse navbar-collapse " id="mynav">
          <ul class="navbar-nav text-light">
              <li class="nav-item">
                <a href="Customerpage.php" class="nav-link">Home</a>
              </li>
              <li class="nav-item">
                <a href="Yorders.php" class="nav-link">Your orders</a>
            </li>
            </li>
          </ul>

          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a href="logout.php" class="nav-link btn btn-danger">logout</a>
            </li>
          </ul>
      </div>
</nav>


<!-- title  Header  -->

<header id="header-customerpage" class="header-customerpage">
    <div class="container">
        <div class="row ">
            <div class="col">
                <div class="banner text-center mt-5">
                    <h3 class="display-1 text-capitalize ">
                        <small class="text-light" >Online</small><strong class="text-danger">Foods</strong>
                    </h3>
                    <a href="#" class="btn main-btn text-capitalize">Order onLine</a>
                </div>
            </div>
        </div>
    </div>

    <!-- <a href="#menu" class="btn header-link text-danger"><i class="fas fa-arrow-down"></i></a> -->
</header>
<!-- End title header -->

    <table class="table text-light striped">
        <thead>
            <th>Firstnane</th>
            <th>Lastname</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Order_Date</th>
            <th>Action</th>
        </thead>

        <tbody>
            <?php if($result) {
              foreach ($result as $row) { ?>
                
            <tr>
               <td><?php echo $row['Firstname'] ?></td>
               <td><?php echo $row['Lastname'] ?></td>
               <td><?php echo $row['Quantity'] ?></td>
               <td><?php echo $row['Total'] ?></td>
               <td><?php echo $row['Order_Date'] ?></td>
                
               <td>
                   <a href="OrderPage.php?idfood=<?php echo $row['ID']?> & idcustomer=<?php echo $ID ?>" class="btn btn-info">Order</a>
               </td>
            </tr>
              <?php }} ?>
        </tbody>
    </table>




<!-- section contact us  -->

<section id="contact_Us" class="contact">
    <h3 class="text-uppercase text-center font-weight-bold py-3"><&nbsp; Contact Us &nbsp;</h3>
    <div class="container-fluid no-padding">
        <div class="row ">
            <div class="col-lg-6 my-5 ">
                <div class="card">
                    <div class="card-header">
                        <h3 class="text-uppercase font-weight-bold text-center bg-info">Contact Us</h3>
                    </div><!--End of  headerka -->

                    <div class="card-body">
                        <form action="">
                        <label for="" class="text-capitalize font-weight-bold ml-3 py-0 text-light"> Name</label>
                            <div class="input-group py-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fas fa-user"></i>
                                    </span>
                                </div><!--End of  input-group-prepend -->
                                <input type="text" class="form-control" placeholder="Enter Name">
                            </div><!--End of  input-group -->

                            <label for="" class="text-capitalize font-weight-bold ml-3 py-0 text-light"> Phone</label>
                            <div class="input-group py-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fas fa-phone-volume"></i>
                                    </span>
                                </div><!--End of  input-group-prepend -->
                                <input type="text" class="form-control" placeholder="Enter phone">
                            </div><!--End of  input-group -->


                            <label for="" class="text-capitalize font-weight-bold ml-3 py-0 text-light"> Email</label>
                            <div class="input-group py-3">
                                <div class="input-group-prepend">
                                    <span class="input-group-text">
                                        <i class="fas fa-envelope-square"></i>
                                    </span>
                                </div><!--End of  input-group-prepend -->
                                <input type="Email" class="form-control" placeholder="Enter Email">
                            </div><!--End of  input-group -->
                            
                        </form><!--End of  form-ka -->

                        <div class="card-footer">
                          <input type="submit" value="Send" class="btn btn-block btn-outline-info transparent-btn ">
                        </div><!--End of  card-footer -->
                    </div><!--End of  card-body -->
                </div><!-- End of card -->
            </div><!--End of  Section col- -->


            <!-- second col -->
            <div class="col-lg-6 align-self-center my-5 opacity-contact">
                <div class="embed-responsive embed-responsive-4by3">
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3934.3884630841367!2d44.083463414163674!3d9.561742283051462!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1628bf46aa978039%3A0xf055674c8c5cee90!2sIMAN%20BUSINESS%20CENTER!5e0!3m2!1sen!2sso!4v1582789400742!5m2!1sen!2sso" 
                 width="800" height="550" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
                </div>
            </div><!--End of  second col-lg-6-->
            
        </div><!--End of  row -->
    </div><!--End of  Contianer Fluid -->
</section><!--End of contact us -->


<!-- Section About US -->

<section id="About_Us">
    <div class="container">
        <div class="row">
           <div class="col-md-5 py-4">
              <h2 class="text-uppercase font-weight-bold text-light"> about us</h2>
              <p class="text-light lead text-capitalize pl-4">
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Hic, facilis!
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Molestias, exercitationem.
                Lorem ipsum dolor sit amet consectetur adipisicing.
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione.
                <a href="#"data-target="#modal" data-toggle="modal"  >Read More</a>
              </p>
              <input type="submit" value="View" class="btn btn-outline-danger ml-4" data-target="#modal" data-toggle="modal">


           <div class="modal fade" id="modal">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header bg-dark">
                            <h3  class="modal-title text-center text-warning text-uppercase font-weight-bold ">about us</h3>
                             <button Type="button" class="text-danger bg-dark" data-dismiss="modal">&times;</button>
                        </div><!--End Of modal header -->

                        <div class="modal-body text-center text-light bg-warning">
                            <p>
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Incidunt, veritatis!
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat.
                            Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ex blanditiis provident explicabo.
                            Lorem ipsum dolor sit amet.
                            </p>
                        </div><!--End Of modal body -->

                        <div class="modal-footer">
                            <input type="close" class="btn btn-danger" value="Close" data-dismiss="modal">
                        </div><!--End Of modal footer -->
                    </div><!--End Of modal content -->
                </div><!--End Of modal dialog -->
           </div><!--End Of modal fade -->
           
           </div><!--End Of col-5 -->


        </div><!--End Of row -->
    </div><!--End Of container-->
</section><!--End Of Section About US -->

<!-- End Of Section about us -->



    <!-- Section footer -->
<div id="footer">
    <div class="container-fluid info ">
        <div class="row">
            <div class="col d-flex justify-content-between align-items-baseline flex-wrap">
            <h3 class="pt-3" >&copy; <strong>Copyright Hargeisain Food all Right Received</strong> </h3>
                <div class="info-icons p-3 primary-icons">
                <a href="#"><i class="fab fa-facebook fa-2x text-primary"></i></a>
                <a href="#"><i class="fab fa-youtube fa-2x text-danger"></i></a>
                <a href="#"><i class="fab fa-twitter fa-2x text-primary"></i></a>
                <a href="#"><i class="fab fa-google fa-2x text-warning"></i></a>
                </div>
                <!-- <a href="#"><i class="fa fa-phone fa-2x text-warning"></i></a> -->
            </div> <!-- End col -->
        </div> <!-- End Of row -->
        
    </div><!-- End Of container-fluid  -->
</div><!-- End Of socil-icon -->








<!-- link Jquery  -->
<script src="js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="js/script.js" ></script>


</body>
</html>