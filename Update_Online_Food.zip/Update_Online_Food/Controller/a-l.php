
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restourant Management System</title>

    <!-- magnific popup css -->
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <!-- google fonts you can add your file any font  -->
    
</head>
<body>

<?php 

    include "../Modal/Login.Class.php";
    $Login = new Login();
    $sign_in = $Login->AdminLogin();


?>

<!-- form  -->

<Section class=""> 
    <div class="container">
        <div class="row mt-4 pt-4">
            <div class="col-md-4 mx-auto text-dark transparent">
           
            <form action="" method="POST" class="needs-validation" novalidate>

                <div class="card transparent">
                    <a href="../admin/Dashboard.php"><i class="fas fa-arrow-left text-dark pt-3 fa-2x"></i></a>
                    <h4 class="card-header text-center text-capitalize font-weight-bold"><i class="fas fa-user text-dark fa-2x"></i></h4>
                    <?php 

                    if(!isset($_GET['signin'])){
    
                    }else{
                        $signincheck = $_GET['signin'];

                        if($signincheck == "validemail"){
                            echo "<p class='error p'>Pleaze Enter Valid Email </p>";
                        }
                        if($signincheck == "num"){
                            echo "<p class='error p'>Only numbers allowed </p>";
                        }
                        if($signincheck == "length_password"){
                            echo "<p class='error p'>Minimum Password upto 1-8 </p>";
                        }
                        if($signincheck == "error"){
                            echo "<p class='error p'>Username Or Password Wrong</p>";
                        }
                        if($signincheck == "select"){
                            echo "<p class='error p'>Please Select Type User</p>";
                        }
                    }
                    ?>
                     <div class="card-body ">
                        <div class="form-row ">
                        <select name="role" id="" class="form-control">
                           <option >-- SELECT TYPE USER</option>
                            <option >Admin</option>
                            <option >User</option>
                        </select>
                        <?php
                         if(isset($_GET['email'])){
                             $email = $_GET['email'];
                             echo '<input type="text" class="textbox form-control " name="email" placeholder="Email" value="'.$email.'" required><br>
                             <div class="invalid-feedback">Empty Emmail</div>';
                         } else{
                            echo '<input type="text" class="textbox form-control " name="email" placeholder="Email" required>';
                         }           
                        ?>
                        <input type="password" class="textbox form-control " name="password" placeholder="Password" required><br>
                        <div class="invalid-feedback">Empty Password!</div>
                        
                        </div><br>
                        <button class="btn btn-primary" name="save" type="submit">Login</button>
                        <input type="hidden" name="actions" id="" value="admin_login"> 
                    </div>
                    <div class="card-footer">
                    
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</Section>
            

<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>


</body>
</html>