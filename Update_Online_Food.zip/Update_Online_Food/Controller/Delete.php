<?php 

    if(isset($_GET['idfood']))
    {    
        include "../Modal/Food.class.php";
        $Food = new Food();
        $idFood = $_REQUEST['idfood'];
        $DeleteFoods = $Food->DeleteFoodsusers($idFood);
    }

    if(isset($_GET['idfood']))
    {    
        include "../Modal/Food.class.php";
        $Food = new Food();
        $idFood = $_REQUEST['idfood'];
        $DeleteFoods = $Food->DeleteFoods($idFood);
    }

    if(isset($_GET['idusers']))
    {    
        include "../Modal/Users.class.php";
        $User = new Users();
        $idusers = $_REQUEST['idusers'];
        $DeleteUsers = $User->DeleteUsers($idusers);
    }

?>