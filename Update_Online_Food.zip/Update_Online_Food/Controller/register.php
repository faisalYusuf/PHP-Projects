
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restourant Management System</title>

    <!-- magnific popup css -->
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <!-- google fonts you can add your file any font  -->
    
</head>
<body>


<!-- Header Login  -->
 <!-- <div class="container-fluid bg-dark sticky-top">
    <h3 class="text-light text-center text-uppercase p-3">sign Up your Account </h3>
 </div> -->



<!-- form  -->
<?php 

 include "../Modal/Registration.Class.php";
 $Register = new Registration();
 $sign_in = $Register->Add_Customer();

?>
<Section class=""> 
    <div class="container">
        <div class="row mt-4 pt-4">
            <div class="col-md-4 mx-auto text-dark transparent">
           
            <form action="" method="POST" class="needs-validation" novalidate>

                <div class="card transparent">
                    <a href="../Public/main.php"><i class="fas fa-arrow-left text-dark pt-3 fa-2x"></i></a>
                    <h4 class="card-header text-center text-capitalize font-weight-bold"><i class="fas fa-user text-dark fa-2x"></i></h4>
                    <?php 
                    //   $fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

                    //   if(strpos($fullurl, "signup=error") == true){
                    //       echo "<p class='error p'>Username Or Password Wrong</p>";
                          
                    //   }

                    if(!isset($_GET['signup'])){
                        
                    }else{
                        $signupcheck = $_GET['signup'];
                        
                        if($signupcheck == "email"){
                            echo "<p class='error p'>Email Has Already taken</p>";
                        }
                        if($signupcheck == "char"){
                            echo "<p class='error p'>Only letters allowed </p>";
                        }
                        if($signupcheck == "num"){
                            echo "<p class='error p'>Only numbers allowed </p>";
                        }
                        if($signupcheck == "length_phone"){
                            echo "<p class='error p'>Pleaze Enter Proper phone number </p>";
                        }
                        if($signupcheck == "length_password"){
                            echo "<p class='error p'>Minimum Password upto 1-8 </p>";
                        }
                        if($signupcheck == "validemail"){
                            echo "<p class='error p'>Pleaze Enter Valid Email </p>";
                        }
                    }
                    ?>
                     <div class="card-body ">
                        <div class="form-row ">
                        <?php 
                        if(isset($_GET['firstname']) ){
                            $firstname = $_GET['firstname'];
                            echo '<input type="text" class="textbox form-control " name="firstname" placeholder="Firstname" value="'.$firstname.'" required><br>
                            <div class="invalid-feedback">Fill Empty Firstname ! </div>';
                        } else{
                            echo '<input type="text" class="textbox form-control " name="firstname" placeholder="Firstname" required><br>
                            <div class="invalid-feedback">Fill Empty Firstname ! </div>';
                        }
                        ?>
                         <?php 
                        if(isset($_GET['lastname']) ){
                            $lastname = $_GET['lastname'];
                            echo '<input type="text" class="textbox form-control " name="lastname" placeholder="lastname" value="'.$lastname.'" required><br>
                            <div class="invalid-feedback">Fiil Empty Lastname  !</div>';
                        } else{
                            echo '<input type="text" class="textbox form-control " name="lastname" placeholder="lastname" required><br>
                            <div class="invalid-feedback">Fiil Empty Lastname  !</div>';
                        }
                        ?>
                        <?php 
                        if(isset($_GET['phone']) ){
                            $phone = $_GET['phone'];
                            echo '<input type="text" class="textbox form-control " name="phone" placeholder="phone" value="'.$phone.'" required><br>
                            <div class="invalid-feedback">Fill Empty Phone number </div>';
                        } else{
                            echo '<input type="text" class="textbox form-control " name="phone" placeholder="phone" required><br>
                            <div class="invalid-feedback">Fill Empty Phone number </div>';
                        }
                        ?>
                        <?php 
                        if(isset($_GET['email']) ){
                            $email = $_GET['email'];
                            echo '<input type="text" class="textbox form-control " name="email" placeholder="email" value="'.$email.'" required><br>
                            <div class="invalid-feedback">Fill Empty Email</div><br>';
                        } else{
                            echo '<input type="text" class="textbox form-control " name="email" placeholder="email" required><br>
                            <div class="invalid-feedback">Fill Empty Email</div><br>';
                        }
                        ?>
                        <?php 
                        if(isset($_GET['password']) ){
                            $password = $_GET['password'];
                            echo '<input type="Password" class="textbox form-control " name="password" placeholder="Password" value="'.$password.'" required><br>
                            <div class="invalid-feedback">Fill Empty Password</div>';
                        } else{
                            echo '<input type="Password" class="textbox form-control " name="password" placeholder="Password" required><br>
                            <div class="invalid-feedback">Fill Empty Password</div>';
                        }
                        ?>
                        
                        </div><br>
                        <button class="btn btn-primary" name="save" type="submit">Register</button>
                        <input type="hidden" name="actions" id="" value="Insert_Customer"> 
                        <h5 class="text-dark pt-2">Already have an account?<a href="sign_in.php">&nbsp;Sign In</a></h5>
                    </div>
                    <div class="card-footer">
                    
                    </div>
                </div>
            </form>
            </div>
        </div>
    </div>
</Section>

<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>


</body>
</html>