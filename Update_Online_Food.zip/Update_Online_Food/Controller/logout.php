<?php 

if(isset($_GET['a-u'])){
    session_start();
    session_destroy();

    header("location: ../admin/Dashboard.php");
}


if(isset($_GET['idcustomer'])){
    session_start();
    session_destroy();

    header("location: ../Public/main.php");
}

?>