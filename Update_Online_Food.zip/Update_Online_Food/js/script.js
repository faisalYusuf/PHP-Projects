$(document).ready(function(){

  // Ripples 
    $("#header, .info").ripples({
        dropRadius: 40,
        perturbance: 0,
      });

      // magnificpopup
      $('.parent-container').magnificPopup({
        delegate: 'a', // child items selector, by clicking on it popup will open
        type: 'image',

        gallery:{
          enabled:true
        }
        // other options
      });

      // smooth scroll
      $('.down a, .header-link').click(function(link){

          link.preventDefault();
          let target = $(this).attr('href');

          $('html,body').animate({
            scrollTop: $(target).offset().top - 25
          },3000)
      })

      // change background nav when scroll down

      $(window).scroll(function(){
          $('nav').toggleClass('scrolled', $(this).scrollTop() > 50);
      });

});



  // Example starter JavaScript for disabling form submissions if there are invalid fields
  (function() {
    'use strict';
    window.addEventListener('load', function() {
      // Fetch all the forms we want to apply custom Bootstrap validation styles to
      var forms = document.getElementsByClassName('needs-validation');
      // Loop over them and prevent submission
      var validation = Array.prototype.filter.call(forms, function(form) {
        form.addEventListener('submit', function(event) {
          if (form.checkValidity() === false) {
            event.preventDefault();
            event.stopPropagation();
          }
          form.classList.add('was-validated');
        }, false);
      });
    }, false);
  })();


  /* Loop through all dropdown buttons to toggle between hiding and showing its dropdown content - This allows the user to have multiple dropdowns without any conflict */
var dropdown = document.getElementsByClassName("dropdown-btn");
var i;


for (i = 0; i < dropdown.length; i++) {
  dropdown[i].addEventListener("click", function() {
  this.classList.toggle("active");
  var dropdownContent = this.nextElementSibling;
  if (dropdownContent.style.display === "block") {
  dropdownContent.style.display = "none";
  } else {
  dropdownContent.style.display = "block";
  }
  });
}


 function  selected(){
    var d=document.getElementById("select");
    var displaytext=d.options[d.selectedIndex].text;
    document.getElementById("textvalue1").value="34345565656";
    document.getElementById("textvalue2").value="234";
 }  