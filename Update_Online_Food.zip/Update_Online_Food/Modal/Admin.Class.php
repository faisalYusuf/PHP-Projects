<?php 
include '../DBConnection/Connection.php';

class Admin extends Connection{


            public function Updatemanager($Idmanager){

                if(isset($_POST['actions']) && $_POST['actions'] == 'Update_Users')
                {
                    $Phone = $_POST['Phone'];
                    $Email = $_POST['Email'];
                    $Password = $_POST['Password'];
                    
                    $query = "UPDATE manager SET Phone='$Phone', Email='$Email', Password='$Password'
                    WHERE ID = $Idmanager";
                    
                    // echo $query;
                
                    $result = $this->conn->query($query);
                    if($result){
                        header("location: ../admin/Dashboard.php");
                    }
                
                }
            
            }


          //  read Users table
          public function Editmanager($Idmanager){

            $query = "SELECT * FROM manager WHERE ID = $Idmanager";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data = $row;
                }
            }
            return $data;
        }

        //  read Manager table
            public function fetch_Data_manager(){

                $query = "SELECT * FROM manager ";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }


            public function coun_number_Customer(){

                $query = "SELECT COUNT(*) as count FROM customers";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }

            public function coun_number_Users(){

                $query = "SELECT COUNT(*) as count FROM orders";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }

            public function coun_number_Order(){

                $query = "SELECT COUNT(*) as count FROM users";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }

}


  



?>