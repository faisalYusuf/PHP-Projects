<?php  

include '../DBConnection/Connection.php';

Class Login extends Connection{

    public function Session_Login(){
        
    if(isset($_POST['actions']) && $_POST['actions'] == 'customer_login')
     {
        $Email = $_POST['email'];
        $pass = $_POST['password'];

    
        if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
            header("location: ../Controller/sign_in.php?signin=validemail");
         
        }else{
            if(!preg_match('/^[0-9]*$/',$pass)){
                header("location: ../Controller/sign_in.php?signin=num&email=$Email");
             }else{
                if(strlen($pass)<8){
                    header("location: ../Controller/sign_in.php?signin=length_password&email=$Email");
                }else{
                    $query = "SELECT * FROM  customers WHERE Email='$Email' and Password ='$pass' LIMIT 1";
                    $result = $this->conn->query($query);

                    if(mysqli_num_rows($result) > 0){
                        foreach ($result as $row) 
                        {
              
                        }
                           session_start();
                           $_SESSION['ID'] = $row['ID'];
                          //  echo  $_SESSION['ID'];
                           $_SESSION['Email'] = $Email;
                          
                           header('location: ../Public/Customerpage.php');
                       }
                       else{
                           header('location:../Controller/sign_in.php?signin=error');
                     }
                }
             }
         }

     }
   
  }


  // admin login
  
  public function AdminLogin(){
        
    if(isset($_POST['actions']) && $_POST['actions'] == 'admin_login')
     {
        $Email = $_POST['email'];
        $pass = $_POST['password'];
        $usertype = $_POST['role'];
    
        if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
            header("location: ../Controller/a-l.php?signin=validemail");
        }else{
            if(!preg_match('/^[0-9]*$/',$pass)){
                header("location: ../Controller/a-l.php?signin=num&email=$Email");
             }else{
                if(strlen($pass)<8){
                    header("location: ../Controller/a-l.php?signin=length_password&email=$Email");
                }else{
                    if($usertype == "Admin"){
                        $query = "SELECT * FROM manager WHERE Email='$Email' and Password ='$pass' LIMIT 1";
                        $result = $this->conn->query($query);

                    if(mysqli_num_rows($result) > 0){
                        foreach ($result as $row) 
                        {
              
                        }
                           session_start();
                           $_SESSION['ID'] = $row['ID'];
                           
                          //  echo  $_SESSION['ID'];
                           $_SESSION['Email'] = $Email;
                          
                           header('location: ../admin/Dashboard.php');
                       }
                       else{
                           header('location:../Controller/a-l.php?signin=error');
                     }
                    }elseif($usertype == "User"){
                        $query = "SELECT * FROM users WHERE Email='$Email' and Password ='$pass' LIMIT 1";
                        $result = $this->conn->query($query);

                        // echo  $query;

                      if(mysqli_num_rows($result) > 0){
                        foreach ($result as $row) 
                        {
              
                        }
                           session_start();
                           $_SESSION['ID'] = $row['ID'];
                          //  echo  $_SESSION['ID'];
                           $_SESSION['Email'] = $Email;
                          
                           header('location: ../Users/UserDashboard.php');
                       }
                       else{
                           header('location:../Controller/a-l.php?signin=error');
                      }
                    }else{
                        header('location:../Controller/a-l.php?signin=select');
                    }
                   
                }
             }
         }

     }
   
  }

}


?>