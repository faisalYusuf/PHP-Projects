<?php  

include '../DBConnection/Connection.php';

class Registration extends Connection{

    public function Add_Customer(){

    if(isset($_POST['actions']) && $_POST['actions'] == 'Insert_Customer')
    {
        $firstname = $_POST['firstname'];
        $lastname = $_POST['lastname'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $password = $_POST['password'];

        if(!preg_match("/^[a-zA-Z\s]+$/",$firstname) || !preg_match("/^[a-zA-Z\s]+$/",$lastname)){
            header("location: ../Controller/register.php?signup=char&phone=$phone&email=$email&password=$password");
        
        }
        else{
            if(!preg_match('/^[0-9]*$/',$phone)){
                header("location: ../Controller/register.php?signup=num&firstname=$firstname&lastname=$lastname&email=$email&password=$password");
              }else{
                 if(strlen($phone)<10){
                     header("location: ../Controller/register.php?signup=length_phone&firstname=$firstname&lastname=$lastname&email=$email&password=$password");
                   }else{
                      if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
                         header("location: ../Controller/register.php?signup=validemail&firstname=$firstname&lastname=$lastname&phone=$phone&password=$password");
                        }else{
                            if(!preg_match('/^[0-9]*$/',$password)){
                                header("location: ../Controller/register.php?signup=num&firstname=$firstname&lastname=$lastname&email=$email&phone=$phone");
                            }else{
                                if(strlen($password)<8){
                                    header("location: ../Controller/register.php?signup=length_password&firstname=$firstname&lastname=$lastname&email=$email&phone=$phone");
                                }else{
                                    $check = "SELECT * FROM  customers WHERE Email ='$email'";
                                    $result = $this->conn->query($check);
                                    if(mysqli_num_rows($result) > 0){
                                        header("location: ../Controller/register.php?signup=email&firstname=$firstname&lastname=$lastname&phone=$phone&password=$password");
                                    }else{
                                        $query = "INSERT INTO customers VALUES(NULL, '$firstname','$lastname','$phone','$email','$password')";
                                        $result = $this->conn->query($query);
                                        if($result){
                                          header("location: ../Controller/sign_in.php");
                                        }
                                    }
                                }     
                            }
                        }
                   }
                }

            }    
        }

    }

     //  read Customers table
     public function fetch_Data_Customers(){

        $query = "SELECT * FROM customers ";
        if($sql = $this->conn->query($query)){
            while($row = mysqli_fetch_assoc($sql)){
                $data[] = $row;
            }
        }
        return $data;
    }
    
}




?>