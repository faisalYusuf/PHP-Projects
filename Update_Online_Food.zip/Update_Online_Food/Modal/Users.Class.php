<?php 
include '../DBConnection/Connection.php';

class Users extends Connection{

        public function AddUsers(){

        if(isset($_POST['actions']) && $_POST['actions'] == 'Insert_Users')
        {
            $Name = $_POST['Name'];
            $Phone = $_POST['Phone'];
            $Email = $_POST['Email'];
            $Password = $_POST['Password'];
            $Manager = $_POST['manager'];


            if(!preg_match("/^[a-zA-Z\s]+$/",$Name)){
                header("location: ../Controller/AddUsers.php?signup=char&phone=$Phone&email=$Email&password=$Password");
            }
            else{
    
                if(!preg_match('/^[0-9]*$/',$Phone)){
                    header("location: ../Controller/AddUsers.php?signup=num&Name=$Name&email=$Email&password=$Password");
                  }else{
                     if(strlen($Phone)<10){
                         header("location: ../Controller/AddUsers.php?signup=length_phone&Name=$Name&email=$Email&password=$Password");
                       }else{
                          if(!filter_var($Email, FILTER_VALIDATE_EMAIL)){
                             header("location: ../Controller/AddUsers.php?signup=validemail&Name=$Name&phone=$Phone&password=$Password");
                            }else{
                                if(!preg_match('/^[0-9]*$/',$Password)){
                                    header("location: ../Controller/AddUsers.php?signup=num&Name=$Name&email=$Email&phone=$Phone");
                                }else{
                                    if(strlen($Password)<8){
                                        header("location: ../Controller/AddUsers.php?signup=length_password&Name=$Name&email=$Email&phone=$Phone");
                                    }else{
                                        $check = "SELECT * FROM users WHERE Email ='$email'";
                                        $result = $this->conn->query($check);
                                        if(mysqli_num_rows($result) > 0){
                                            header("location: ../Controller/AddUsers.php?signup=email&Name=$Name&phone=$Phone&password=$Password");
                                        }else{
                                            
                                            $query = "INSERT INTO users VALUES(NULL, '$Name','$Phone','$Email','$Password','$Manager')";
                                            $result = $this->conn->query($query);
                                            if($result){
                                                header("location: ../View/ViewUsers.php");
                                            }
                                        }
                                    }     
                                }
                            }
                       }
                    }
    
                }
        
            }

        }



            public function UpdateUsers($IdUsers){

                if(isset($_POST['actions']) && $_POST['actions'] == 'Update_Users')
                {
                    $Name = $_POST['Name'];
                    $Phone = $_POST['Phone'];
                    $Email = $_POST['Email'];
                    $Password = $_POST['Password'];
                    $Manager = $_POST['manager'];
                    $id = $IdUsers;
            
                    $query = "UPDATE users SET Name='$Name', Phone='$Phone', Email='$Email', Password='$Password',Manager_ID='$Manager' 
                    WHERE ID = $id";
                    
                    // echo $query;
                
                    $result = $this->conn->query($query);
                    if($result){
                        header("location: ../View/ViewUsers.php");
                    }
                
                }
            
            }

    
       //  Delete Users table
        public function DeleteUsers($idusers){

            $query = "DELETE FROM users WHERE ID = $idusers";
            if($sql = $this->conn->query($query))
            {
                header("location: ../View/ViewUsers.php");
            }

        }


       //  read Users table
        public function EditUsers($IdUsers){

            $query = "SELECT * FROM users WHERE ID = $IdUsers";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data = $row;
                }
            }
            return $data;
        }
        

    //  read Users table
        public function fetch_Data_Users(){

            $query = "SELECT * FROM users ";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data[] = $row;
                }
            }
            return $data;
        }

        //  read Manager table
            public function fetch_Data_manager(){

                $query = "SELECT * FROM manager ";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }


            public function coun_number_Customer(){

                $query = "SELECT COUNT(*) as count FROM customers";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }

            public function coun_number_Users(){

                $query = "SELECT COUNT(*) as count FROM orders";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }

            public function coun_number_Order(){

                $query = "SELECT COUNT(*) as count FROM users";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }

}


  



?>