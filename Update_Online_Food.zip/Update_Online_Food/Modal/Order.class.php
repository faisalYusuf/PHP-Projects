<?php 
include '../DBConnection/Connection.php';
    
class Order extends Connection{

      // Insert Order Table Food 
      public function AddOrder(){

        if(isset($_POST['actions']) && $_POST['actions'] == 'Order_Food')
        {
            
            $food = $_POST['idFood'];
            $Customer = $_POST['idcustomer'];
            $Quantity = $_POST['quantity'];
            $total = $_POST['total'];
            $DeliveryPrice = $_POST['DeliveryPrice'];
            $typemoney = $_POST['money'];
            $add = $Quantity * $total;
            $sum = $add + $DeliveryPrice;
            

                   if($typemoney == "Money_Type"){
                        
                        
                        $insert_Orders = "INSERT INTO Orders (Customer_ID ,Delivery_Price, Order_Date) VALUES($Customer, now() ,$DeliveryPrice)";
                        // echo $insert_Orders;
                        if($sql = $this->conn->query($insert_Orders)){
                        
                            $Select_Last_Order_Number = "SELECT Order_Number FROM Orders order by Order_Number desc limit 1";
                            $result_Select_Number = $this->conn->query($Select_Last_Order_Number);
                            $Last_Order_Number = mysqli_fetch_array($result_Select_Number);
                            $Order_Number = $Last_Order_Number[0];
            
                            $insert_quary = "INSERT INTO order_details (Order_Number, Kitchen_ID, Quantity, Total) 
                            VALUES($Order_Number, $food, $Quantity, $sum)";
                            if($sql = $this->conn->query($insert_quary)){
                                header("location: ../Public/orderhistory.php");
                            }else{
                                echo "Operation Was not Found";
                            }
            
                        }else{
                            echo "Cant Save Any thing";
                        }
                   }else{
                    $idfood = $_GET['idfood'];
                    $idcustomer = $_GET['idcustomer'];
                    header("location: ../Public/OrderPage.php?signup=select&idfood=$idfood&idcustomer=$idcustomer");
                   }
                
            
        }
    }




    
      //  read Kitchen table
      public function fetch_Data_kitchen(){

        $query = "SELECT * FROM kitchen ";
        if($sql = $this->conn->query($query)){
            while($row = mysqli_fetch_assoc($sql)){
                $data[] = $row;
            }
        }
        return $data;
    }

       //  read Kitchen table
       public function ShowOnlySelectedOrder($idFood){

        $query = "SELECT * FROM kitchen WHERE ID = $idFood";
        if($sql = $this->conn->query($query)){
            while($row = mysqli_fetch_assoc($sql)){
                $data[] = $row;
            }
        }
        return $data;
    }

}


?>