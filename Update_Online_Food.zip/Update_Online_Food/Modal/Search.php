<?php 
include '../DBConnection/Connection.php';

class Search extends Connection{

        //  read Kitchen table
        public function SearchData(){

            if(isset($_POST['search']))
            
            {
                $searchkey = $_POST['search'];
                $query = "SELECT customers.Firstname, customers.Lastname, orders.Order_Date, order_Details.Quantity,order_Details.Total 
                FROM customers
                INNER JOIN Orders ON orders.Customer_ID = customers.ID
                INNER JOIN order_Details ON Orders.Order_Number = order_Details.Order_Number WHERE Firstname like '%$searchkey %'";
               
           }else{
                $query = "SELECT customers.Firstname, customers.Lastname, orders.Order_Date, order_Details.Quantity,order_Details.Total 
                FROM customers
                INNER JOIN Orders ON orders.Customer_ID = customers.ID
                INNER JOIN order_Details ON Orders.Order_Number = order_Details.Order_Number";
           }

               $sql = $this->conn->query($query);  
        }


              //  read Data from table customer
              public function fetch_Data_Search(){

                $query = "SELECT customers.Firstname, customers.Lastname, orders.Order_Date, order_Details.Quantity,order_Details.Total 
                FROM customers
                INNER JOIN Orders ON orders.Customer_ID = customers.ID
                INNER JOIN order_Details ON Orders.Order_Number = order_Details.Order_Number";
                if($sql = $this->conn->query($query)){
                    while($row = mysqli_fetch_assoc($sql)){
                        $data[] = $row;
                    }
                }
                return $data;
            }


  
}


?>