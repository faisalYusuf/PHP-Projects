<?php 
include '../DBConnection/Connection.php';

class Food extends Connection{

        public function AddFood(){

        if(isset($_POST['actions']) && $_POST['actions'] == 'Insert_Food')
        {
            $Food_Name = $_POST['Food_Name'];
            $image = $_FILES['Image']['name'];
            $filetemp = $_FILES['Image']['tmp_name'];
            $filetype = $_FILES["Image"]["type"];
            $Discription = $_POST['Description'];
            $Quantity = $_POST['Quantity'];
            $Price = $_POST['Price'];
            $user = $_POST['User'];

            $Folder ="../Upload_Images/";
            
            move_uploaded_file($filetemp , $Folder.$image);

            if(!preg_match("/^[a-zA-Z\s]+$/",$Food_Name)){
                header("location: ../Controller/AddFoods.php?addfood=char&Discription=$Discription&Quantity=$Quantity&Price=$Price");
            }else{
                if(!preg_match("/^[a-zA-Z\s]+$/",$Discription)){
                   header("location: ../Controller/AddFoods.php?addfood=char&foodnmae=$Food_Name&Quantity=$Quantity&Price=$Price");
                }else{
                    if(!preg_match('/^[0-9]*$/',$Quantity)){
                        header("location: ../Controller/AddFoods.php?addfood=num&foodnmae=$Food_Name&Discription=$Discription&Price=$Price");
                    }else{
                        if(!preg_match('/^[0-9]*$/',$Price)){
                            header("location: ../Controller/AddFoods.php?addfood=num&foodnmae=$Food_Name&Discription=$Discription&Quantity=$Quantity");
                        }else{
                            if($filetype != "image/jpeg"  && $filetype != "image/jpg" && $filetype != "image/png" && $filetype != "image/gif" ){
                                header("location: ../Controller/AddFoods.php?addfood=type&foodnmae=$Food_Name&Discription=$Discription&Quantity=$Quantity&Price=$Price");
                            }else{
                                $query = "INSERT INTO kitchen VALUES(NULL, '$Food_Name','$image','$Discription','$Quantity',' $Price','$user')";                        
                                $result = $this->conn->query($query);
                                if($result){
                                    header("location: ../View/ViewFoods.php");
                                }
                            }
                        }
                    }
                }
            }
 
        }

     }


     public function AddFoodusers(){

        if(isset($_POST['actions']) && $_POST['actions'] == 'Insert_Food')
        {
            $Food_Name = $_POST['Food_Name'];
            $image = $_FILES['Image']['name'];
            $filetemp = $_FILES['Image']['tmp_name'];
            $filetype = $_FILES["Image"]["type"];
	        $filesize = $_FILES["file_img"]["size"];
            $Discription = $_POST['Description'];
            $Quantity = $_POST['Quantity'];
            $Price = $_POST['Price'];
            $user = $_POST['User'];

            $Folder ="../Upload_Images/";
            
            move_uploaded_file($filetemp , $Folder.$image);

            if(!preg_match("/^[a-zA-Z\s]+$/",$Food_Name)){
                header("location: ../Controller/AddFoods.php?addfood=char&Discription=$Discription&Quantity=$Quantity&Price=$Price");
            }else{
                if(!preg_match("/^[a-zA-Z\s]+$/",$Discription)){
                   header("location: ../Controller/AddFoods.php?addfood=char&foodnmae=$Food_Name&Quantity=$Quantity&Price=$Price");
                }else{
                    if(!preg_match('/^[0-9]*$/',$Quantity)){
                        header("location: ../Controller/AddFoods.php?addfood=num&foodnmae=$Food_Name&Discription=$Discription&Price=$Price");
                    }else{
                        if(!preg_match('/^[0-9]*$/',$Price)){
                            header("location: ../Controller/AddFoods.php?addfood=num&foodnmae=$Food_Name&Discription=$Discription&Quantity=$Quantity");
                        }else{
                            if($filetype != "image/jpeg"  && $filetype != "image/jpg" && $filetype != "image/png" && $filetype != "image/gif" ){
                                header("location: ../Controller/AddFoods.php?addfood=type&foodnmae=$Food_Name&Discription=$Discription&Quantity=$Quantity&Price=$Price");
                            }else{
                                $query = "INSERT INTO kitchen VALUES(NULL, '$Food_Name','$image','$Discription','$Quantity',' $Price',1,'$user')";                        
                                $result = $this->conn->query($query);
                                if($result){
                                    header("location: ../Users/ViewFoods.php");
                                }
                            }
                        }
                    }
                }
            }

        }

     }


        
        public function UpdateFoods($IdFoods){

            if(isset($_POST['actions']) && $_POST['actions'] == 'UpdateFoods')
            {
                $data['Food_Name'] = $_POST['Food_Name'];
                $data['image'] = $_FILES['Image']['name'];
                $filetemp = $_FILES['Image']['tmp_name'];
                $data['Description'] = $_POST['Description'];
                $data['Quantity'] = $_POST['Quantity'];
                $data['Price'] = $_POST['Price'];
                $data['user'] = $_POST['User'];
                $data['id'] = $IdFoods;

                $Folder ="../Upload_Images/";
                
                move_uploaded_file($filetemp , $Folder.$image);

                $query = "UPDATE kitchen SET Name='$data[Food_Name]', Image='$data[image]',Discription='$data[Description]',Quantity='$data[Quantity]', Price='$data[Price]',User_ID='$data[user]'
                WHERE ID = $data[id]";
                
                // echo $query;
            
                $result = $this->conn->query($query);

                // echo $query;
                if($result){
                    header("location: ../View/ViewFoods.php");
                }
            
            }

        }

             
        public function UpdateFoodsUser($IdFoods){

            if(isset($_POST['actions']) && $_POST['actions'] == 'UpdateFoods')
            {
                $data['Food_Name'] = $_POST['Food_Name'];
                $data['image'] = $_FILES['Image']['name'];
                $filetemp = $_FILES['Image']['tmp_name'];
                $data['Description'] = $_POST['Description'];
                $data['Quantity'] = $_POST['Quantity'];
                $data['Price'] = $_POST['Price'];
                $data['user'] = $_POST['User'];
                $data['id'] = $IdFoods;

                $Folder ="../Upload_Images/";
                
                move_uploaded_file($filetemp , $Folder.$image);

                $query = "UPDATE kitchen SET Name='$data[Food_Name]', Image='$data[image]',Discription='$data[Description]',Quantity='$data[Quantity]', Price='$data[Price]',User_ID='$data[user]'
                WHERE ID = $data[id]";
                
                // echo $query;
            
                $result = $this->conn->query($query);

                // echo $query;
                if($result){
                    header("location: ../Users/ViewFoods.php");
                }
            
            }

        }


        //  Edit Food table
        public function EditFoods($IdFoods){

            $query = "SELECT * FROM kitchen WHERE ID = $IdFoods";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data = $row;
                }
            }
            return $data;
        }


       //  Delete Kitchen table
       public function DeleteFoods($idFood){

        $query = "DELETE FROM kitchen WHERE ID = $idFood";
        if($sql = $this->conn->query($query))
        {
            header("location: ../View/ViewFoods.php");
        }

      }

      
       //  Delete Kitchen table
       public function DeleteFoodsusers($idFood){

        $query = "DELETE FROM kitchen WHERE ID = $idFood";
        if($sql = $this->conn->query($query))
        {
            header("location: ../Users/ViewFoods.php");
        }

      }


      //  read Kitchen table
        public function fetch_Data_kitchen(){

            $query = "SELECT * FROM kitchen ";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data[] = $row;
                }
            }
            return $data;
        }

           //  read Kitchen table
           public function ShowOnlySelectedOrder($idFood){

            $query = "SELECT * FROM kitchen WHERE ID = $idFood";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data[] = $row;
                }
            }
            return $data;
        }

        //  read Kitchen table
        public function fetch_Data_User(){

            $query = "SELECT * FROM users ";
            if($sql = $this->conn->query($query)){
                while($row = mysqli_fetch_assoc($sql)){
                    $data[] = $row;
                }
            }
            return $data;
        }

        
        public function Updatedactive($idfood){
            
            $query = "UPDATE kitchen SET Status ='0' WHERE ID = $idfood ";
            //  echo  $query;

              if($sql = $this->conn->query($query)){
                header("location: ../Users/ViewFoods.php");
              }
              else{
                 echo "<script> alert('Not Active Room ')</script>";
                 echo "<script>window.location.href='EditRooms.php';</script>";
              }
        }

        public function Updateddisactive($idfood){
            
            $query = "UPDATE kitchen SET Status ='1' WHERE ID = $idfood ";
            //  echo  $query;

              if($sql = $this->conn->query($query)){
                header("location: ../Users/ViewFoods.php");
                // echo "<script> alert('active room ')</script>";
                 
              }
              else{
                 echo "<script> alert('error ')</script>";
                 echo "<script>window.location.href='EditRooms.php';</script>";
              }
        }

}


  



?>