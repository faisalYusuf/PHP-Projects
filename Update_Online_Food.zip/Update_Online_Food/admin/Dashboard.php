<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A-d-M-n-P</title>
    
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <link href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css" rel="stylesheet">
    
</head>
<body>


<?php  
    session_start();
    $ID = $_SESSION['ID'];
    $Email = $_SESSION['Email'];
    if(isset($_SESSION['Email'])){
        include "../Modal/Admin.class.php";
        $Admin = new Admin();
        $Idmanager  = $ID;
        $Editmanager = $Admin->Editmanager($Idmanager);
        $Updatemanager = $Admin->Updatemanager($Idmanager);
        $fetch_Data_manager = $Admin->fetch_Data_manager();
        $coun_number_Customer = $Admin->coun_number_Customer();
        $coun_number_Users = $Admin->coun_number_Users();
        $coun_number_Order = $Admin->coun_number_Order();
    }

    else{
        header("location: ../Controller/a-l.php");
    }

    // include_once "../Modal/Search.php";
    // $Search = new Search();
    // $SearchData = $Search->SearchData();
    // $Fetch_Data_search = $Search->fetch_Data_Search();

?>

<div class="container-fluid fixed-top ">
    <div class="row">
        <div class="col-10  top-header  ">

        <nav class="navbar navbar-expand-sm ">
            <!-- Brand -->
            <a class="navbar-brand" href="Dashboard.php">ADMIN PANEL</a>

            <!-- Links -->
            <ul class="navbar-nav ml-auto">
                <!-- Dropdown -->
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbardrop" data-toggle="dropdown">
                  <i class="fas fa-user fa-1x"></i> <?php echo $Email; ?>
                </a>
                <div class="dropdown-menu down-menu">
                    <a class="dropdown-item" href="#">profile</a>
                    <!-- <a class="dropdown-item" href="">account</a> -->
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-primary dropdown-item" data-toggle="modal" data-target="#exampleModal"> change account</button>
                    <a class="dropdown-item btn btn-danger"  href="../Controller/logout.php?a-u=<?php echo $ID;?>">Logout</a>
                </div>
                </li>
           </ul>
         </nav>

        </div><!-- End of col-->
    </div><!-- End of row-->
</div><!-- End of container-->


    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <?php 
                 $fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

                 if(strpos($fullurl, "signup=error_rooms") == true){
                    echo "<p class='error p'>Incorrect Input Value</p>";
                 }
                ?>
                <form action="" method="POST" class="needs-validation"  enctype="multipart/form-data" novalidate>
                <div class="form-row">
            
                <label for="validationCustom01">Phone</label>
                <input type="tel" class="form-control" name="Phone" placeholder="Phone" value="<?php echo $Editmanager['Phone'] ?>"  required><br>
                <div class="invalid-feedback">Fill  Phone Number!</div><br>
                <label for="validationCustom01">Email</label>
                <input type="Email" min="1" max="50" class="form-control" name="Email" value="<?php echo $Editmanager['Email'] ?>"  placeholder="Example@gmail.com" required><br>
                <div class="invalid-feedback">Fill  Email!</div><br>
                <label for="validationCustom01">Password</label>
                <input type="text" min="0" max="8" class="form-control" name="Password" value="<?php echo $Editmanager['Password'] ?>"  placeholder="Password" required><br>
                <div class="invalid-feedback">Fill The Password !</div><br>
                
                 <input type="submit" class="btn btn-info btn-block" name="save" value="Update" >
                 <input type="hidden" name="actions" value="Update_Users">
                </div>
             </form>
        </div><!-- End Of modal body -->
        <div class="modal-footer">
            <!-- <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-success">Save changes</button> -->
        </div><!-- End Of modal footer -->

        </div><!-- End Of modal content -->
      </div><!-- End Of modal dialog -->
    </div><!-- End Of modal fade -->

    <!-- ANother Row -->
    <div class="container-fluid align-container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidenav">

                     <div class="text-center text-light mb-5 ">
                        <i class="fas fa-user fa-2x"></i>
                        <h5 class="text-capitalize">my account</h5>
                     </div>
                    
                    
                     <a href="Dashboard.php" class="">&nbsp; &nbsp;<i class="fas fa-home  manage-icon active  text-primary"></i>home</a>
                    <button class="dropdown-btn"><i class="fas fa-user-friends  manage-icon text-primary"></i>Foods
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../Controller/AddFoods.php">Add Food</a>
                        <a href="../View/ViewFoods.php">List Foods</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-chess-rook  manage-icon text-primary"></i>&nbsp;&nbsp;Users 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container"><i class=""></i>
                        <a href="../Controller/AddUsers.php">Add Users</a>
                        <a href="../View/viewUsers.php">Manage Users</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Orders 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewOrders.php">View Orders</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Customer
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewCustomers.php">List Customers</a>
                    </div>
               </div>
          </div>

          <!-- content you write any thing to show the user  -->
      
            <div class="col-md-9 content">
                 <div class="row">

                 <!-- col 2 -->
                   <div class="col-md-4">           
                         <div class="card card-transparent">

                             <div class="card-header text-center text-uppercase text-light">
                                <h3>customer</h3>
                             </div>

                             <div class="card-body text-center ">
                                 <?php if($coun_number_Customer) {
                                     foreach ($coun_number_Customer as $row) {?>
                                 <div class="d-flex justify-content-between">
                                     <p class="text-capitalize">range</p>
                                     <i class="fas fa-retweet text-info"></i>
                                 </div>
                                  <h2 class="display-4"><?php echo $row['count']?></h2>
                                 <?php }}?>
                             </div>

                    </div><!-- End OF card -->
                 </div> <!-- End OF col -->
                    


                   <!-- col 3 -->
                   <div class="col-md-4">           
                         <div class="card card-transparent">

                             <div class="card-header text-center text-uppercase text-light">
                                <h3>Users</h3>
                             </div>

                             <div class="card-body text-center ">
                                <?php if($coun_number_Order) {
                                    foreach ($coun_number_Order as $row) {?>
                                 <div class="d-flex justify-content-between">
                                     <p class="text-capitalize">range</p>
                                     <i class="fas fa-retweet text-success"></i>
                                 </div>
                                 <h2 class="display-4"><?php echo $row['count']?></h2>
                                 <?php }}?>
                             </div>

                    </div><!-- End OF card -->
                 </div> <!-- End OF col -->


                   <!-- col 4 -->
                      <div class="col-md-4">           
                         <div class="card card-transparent">

                             <div class="card-header text-center text-uppercase text-light">
                                <h3>Orders</h3>
                             </div>

                             <div class="card-body text-center ">
                                <?php if($coun_number_Users) {
                                    foreach ($coun_number_Users as $row) {?>
                                 <div class="d-flex justify-content-between">
                                     <p class="text-capitalize">range</p>
                                     <i class="fas fa-retweet text-danger"></i>
                                 </div>
                                 <h2 class="display-4"><?php echo $row['count']?></h2>
                                 <?php }}?>
                             </div>

                    </div><!-- End OF card -->
                 </div> <!-- End OF col -->
            </div><!-- End OF row -->

            <!-- row two -->

            <div class="row">
                <div class="col text-center mt-4">
                    <!-- <img src="images/26.jpg"  class="img-fluid"alt=""> -->
                            <!-- <form action="" method="POST" >
                                <input type="search" name="search" class="ml-auto" value="<?php //echo $SearchData;?>">
                            </form> -->
                        <div class="card card-transparent">
                             <div class="card-body text-center ">
                             <!-- <table id="example" class="table text-light striped">
                             <thead>
                                <th>Firstnane</th>
                                <th>Lastname</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Order_Date</th>
                                <th>Action</th>
                            </thead>

                            <tbody>
                                <?php //if($Fetch_Data_search) {
                                //foreach ($Fetch_Data_search as $row) { ?>
                                    
                                <tr>
                                <td><?php //echo $row['Firstname'] ?></td>
                                <td><?php //echo $row['Lastname'] ?></td>
                                <td><?php //echo $row['Quantity'] ?></td>
                                <td><?php //echo $row['Total'] ?></td>
                                <td><?php //echo $row['Order_Date'] ?></td>
                                    
                                <td>
                                    <a href="OrderPage.php?idfood=<?php //echo $row['ID']?> & idcustomer=<?php //echo $ID ?>" class="btn btn-info"></a>
                                </td>
                                </tr>
                                <?php //}} ?>
                            </tbody>
                        </table> -->
                    </div>
                    </div><!-- End OF card -->

                </div>
            </div>
      </div> <!-- End OF Content -->




<script>
    $(document).ready(function() {
    $('#example').DataTable();
    } );
</script>

<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>
<script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js" ></script>
<script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js" ></script>

</body>
</html>