<?php 
 include "../Modal/Food.class.php";
$Food = new Food();
$idfood = $_REQUEST['idfood'];
$Updatedactive = $Food->Updatedactive($idfood);
?>