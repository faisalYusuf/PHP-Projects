<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A-d-M-n-P</title>
    
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">

</head>
<body>



<?php  
  session_start();
  $ID = $_SESSION['ID'];
  $Email = $_SESSION['Email'];
  if(isset($_SESSION['Email'])){

  }

  else{
      header("location: ../Controller//a-l.php");
  }

    include "../Modal/Food.class.php";
    $Food = new Food();
    $IdFoods = $_REQUEST['idfood'];
    $EditFoods = $Food->EditFoods($IdFoods);
    $UpdateFoodsUser = $Food->UpdateFoodsUser($IdFoods);
    $fetch_Data_User = $Food->fetch_Data_User();

?>

<div class="container-fluid fixed-top ">
    <div class="row">
        <div class="col-10  top-header  ">

        <nav class="navbar navbar-expand-sm ">
            <!-- Brand -->
            <a class="navbar-brand" href="UserDashboard.php">ADMIN PANEL</a>

            <!-- Links -->
            <ul class="navbar-nav ml-auto">
                <!-- Dropdown -->
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbardrop" data-toggle="dropdown">
                  <i class="fas fa-user fa-1x"></i> <?php echo $Email; ?>
                </a>
                <div class="dropdown-menu down-menu">
                    <!-- <a class="dropdown-item" href="#">profile</a> -->
                    <!-- <a class="dropdown-item" href="">account</a> -->
                    <!-- Button trigger modal -->
                    <!-- <button type="button" class="btn btn-primary dropdown-item" data-toggle="modal" data-target="#exampleModal"> change account</button> -->
                    <a class="dropdown-item btn btn-danger"  href="../Controller/logout.php?a-u=<?php echo $ID;?>">Logout</a>
                </div>
                </li>
           </ul>
         </nav>

        </div><!-- End of col-->
    </div><!-- End of row-->
</div><!-- End of container-->


    <!-- ANother Row -->
    <div class="container-fluid align-container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidenav">

                     <div class="text-center text-light mb-5 ">
                        <i class="fas fa-user fa-2x"></i>
                        <h5 class="text-capitalize">my account</h5>
                     </div>
                    
                    
                     <a href="UserDashboard.php" class="">&nbsp; &nbsp;<i class="fas fa-home  manage-icon active  text-primary"></i>home</a>
                    <button class="dropdown-btn"><i class="fas fa-user-friends  manage-icon text-primary"></i>Foods
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="AddFoods.php">Add Food</a>
                        <a href="ViewFoods.php">List Foods</a>
                    </div>
                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Orders 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="ViewOrders.php">View Orders</a>
                    </div>

                 
               </div>
          </div>

          <!-- content you write any thing to show the user  -->
      
            <div class="col-md-9 content">

                <div class="row">
                  <div class="col-lg-11 mx-auto ">
                    <div class="form-group">
                    <div class="card text-dark card-transparent">
                            <div class="card-header text-uppercase text-light">Foods</div>
                            <div class="card-body text-light">
                            <?php 
                            $fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

                            if(strpos($fullurl, "signup=error_rooms") == true){
                                echo "<p class='error p'>Incorrect Input Value</p>";
                            }
                            ?>
                            <form action="" method="POST" class="needs-validation"  enctype="multipart/form-data" novalidate>
                            <div class="form-row">
                            <label for="validationCustom01">Food Name</label>
                            <input type="text" class="form-control" name="Food_Name" value="<?php echo $EditFoods['Name']?>" placeholder="Food Name" required><br>
                            <div class="invalid-feedback">Fill Food Name </div><br>

                            <label for="validationCustom01">Description</label>
                            <input type="text" class="form-control" name="Description" value="<?php echo $EditFoods['Discription']?>" placeholder="Description" required><br>
                            <div class="invalid-feedback">Empty Description Of the Image !</div><br>

                            <label for="validationCustom01">Queantity</label>
                            <input type="number" min="1" max="50" class="form-control" value="<?php echo $EditFoods['Quantity']?>" name="Quantity" placeholder="4" required><br>
                            <div class="invalid-feedback">Empty Quantity!</div><br>

                            <label for="validationCustom01">Price</label>
                            <input type="number" min="1" max="50" class="form-control" value="<?php echo $EditFoods['Price']?>" name="Price" placeholder="$7" required><br>
                            <div class="invalid-feedback">Empty Price !</div><br>
                            
                            <label for="validationCustom01">User</label>
                            <select name="User" id="" class="form-control">
                                <?php 
                                 foreach ($fetch_Data_User as $fetch_Data_Users) {?>

                                <option value="<?php echo $fetch_Data_Users['ID']; ?>"><?php echo $fetch_Data_Users['Name']; ?></option><br>
                                
                                 <?php }?>
                            </select>
                            <div class="invalid-feedback">Empty User !</div><br><br>
                            
                            <input  type="file" name="Image" required>
                            <div class="invalid-feedback">Valid Upload Image!</div><br>
                            </div><br>
                            <input type="submit" class="btn btn-secondary btn-block card-transparent" name="save" value="Update" >
                            <input type="hidden" name="actions" value="UpdateFoods">
                        </div>
                    </form>
                    </div><!-- End OF card body -->
                </div><!-- End OF card -->
                    </div><!-- End of form group -->
            </div><!-- End of col -->
            
            </div>
        </div><!-- End of row -->

    </div> <!-- End OF Content -->






<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>
</body>
</html>