<?php 
 include "../Modal/Food.class.php";
$Food = new Food();
$idfood = $_REQUEST['idfood'];
$Updateddisactive = $Food->Updateddisactive($idfood);
?>