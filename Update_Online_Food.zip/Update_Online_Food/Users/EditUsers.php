<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>A-d-M-n-P</title>
    
    <link rel="stylesheet" href="../css/magnific-popup.css">
    <!--bootstrap sytle   -->
     <link rel="stylesheet" href="../css/bootstrap.css">
     <!-- my own css  -->
     <link rel="stylesheet" href="../css/style.css">
     <!-- font awesome js all icons  -->
     <script src="../js/all.js" ></script>
     <link href="https://fonts.googleapis.com/css2?family=Patrick+Hand&display=swap" rel="stylesheet">

</head>
<body>



<?php  

session_start();
$ID = $_SESSION['ID'];
$Email = $_SESSION['Email'];
if(isset($_SESSION['Email'])){

}

else{
    header("location: ../Controller//a-l.php");
}

    include "../Modal/Users.class.php";
    $Users = new Users();
    $IdUsers  = $_REQUEST['idusers'];
    $EditUsers = $Users->EditUsers($IdUsers);
    $UpdateUsers = $Users->UpdateUsers($IdUsers);
    $fetch_Data_manager = $Users->fetch_Data_manager();

?>
<div class="container-fluid fixed-top ">
    <div class="row">
        <div class="col-10  top-header  ">

        <nav class="navbar navbar-expand-sm ">
            <!-- Brand -->
            <a class="navbar-brand" href="UserDashboard.php">ADMIN PANEL</a>

            <!-- Links -->
            <ul class="navbar-nav ml-auto">
                <!-- Dropdown -->
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" href="#" id="navbardrop" data-toggle="dropdown">
                  <i class="fas fa-user fa-1x"></i> <?php echo $Email; ?>
                </a>
                <div class="dropdown-menu down-menu">
                    <!-- <a class="dropdown-item" href="#">profile</a> -->
                    <!-- <a class="dropdown-item" href="">account</a> -->
                    <!-- Button trigger modal -->
                    <!-- <button type="button" class="btn btn-primary dropdown-item" data-toggle="modal" data-target="#exampleModal"> change account</button> -->
                    <a class="dropdown-item btn btn-danger"  href="../Controller/logout.php?a-u=<?php echo $ID;?>">Logout</a>
                </div>
                </li>
           </ul>
         </nav>

        </div><!-- End of col-->
    </div><!-- End of row-->
</div><!-- End of container-->

    <!-- ANother Row -->
    <div class="container-fluid align-container">
        <div class="row">
            <div class="col-md-3">
                <div class="sidenav">

                     <div class="text-center text-light mb-5 ">
                        <i class="fas fa-user fa-2x"></i>
                        <h5 class="text-capitalize">my account</h5>
                     </div>
                    
                    
                     <a href="../admin/Dashboard.php" class="">&nbsp; &nbsp;<i class="fas fa-home  manage-icon active  text-primary"></i>home</a>
                    <button class="dropdown-btn"><i class="fas fa-user-friends  manage-icon text-primary"></i>Foods
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../Controller/AddFoods.php">Add Food</a>
                        <a href="../View/ViewFoods.php">List Foods</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-chess-rook  manage-icon text-primary"></i>&nbsp;&nbsp;Users 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container"><i class=""></i>
                        <a href="../Controller/AddUsers.php">Add Users</a>
                        <a href="../View/viewUsers.php">Manage Users</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Orders 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewOrders.php">View Orders</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Customer
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewCustomers.php">List Customers</a>
                    </div>

                    <button class="dropdown-btn"><i class="fas fa-building  manage-icon text-primary"></i>&nbsp;&nbsp;Payment 
                       <span> <i class="fa fa-caret-down fa-2x"></i></span>
                    </button>
                    <div class="dropdown-container">
                        <a href="../View/ViewPayment.php">View Payment</a>
                    </div> 
               </div>
          </div>

          <!-- content you write any thing to show the user  -->
      
            <div class="col-md-9 content">

                <div class="row">
                  <div class="col-lg-11 mx-auto ">
                    <div class="form-group">
                    <div class="card text-dark card-transparent">
                            <div class="card-header text-uppercase text-light">Users</div>
                            <div class="card-body text-light">
                            <?php 
                            $fullurl = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

                            if(strpos($fullurl, "signup=error_rooms") == true){
                                echo "<p class='error p'>Incorrect Input Value</p>";
                            }
                            ?>
                            <form action="" method="POST" class="needs-validation"  enctype="multipart/form-data" novalidate>
                            <div class="form-row">
                            <label for="validationCustom01">Full Name</label>
                            <input type="text" class="form-control" name="Name" placeholder="Name" value="<?php echo $EditUsers['Name'] ?>" required><br>
                            <div class="invalid-feedback">Fill Name! </div><br>

                            <label for="validationCustom01">Phone</label>
                            <input type="tel" class="form-control" name="Phone" placeholder="Phone" value="<?php echo $EditUsers['Phone'] ?>"  required><br>
                            <div class="invalid-feedback">Fill  Phone Number!</div><br>

                            <label for="validationCustom01">Email</label>
                            <input type="Email" min="1" max="50" class="form-control" name="Email" value="<?php echo $EditUsers['Email'] ?>"  placeholder="Example@gmail.com" required><br>
                            <div class="invalid-feedback">Fill  Email!</div><br>

                            <label for="validationCustom01">Password</label>
                            <input type="text" min="0" max="8" class="form-control" name="Password" value="<?php echo $EditUsers['Password'] ?>"  placeholder="Password" required><br>
                            <div class="invalid-feedback">Fill The Password !</div><br>
                            
                            <label for="validationCustom01">Manager</label>
                            <select name="manager" id="" class="form-control">
                                <?php 
                                 foreach ($fetch_Data_manager as $fetch_Data_Manager) {?>

                                <option value="<?php echo $fetch_Data_Manager['ID']; ?>"><?php echo $fetch_Data_Manager['Title']; ?></option><br>
                                
                                 <?php }?>
                            </select>
                            <div class="invalid-feedback">Empty Manager !</div><br><br>
                            <input type="submit" class="btn btn-secondary btn-block card-transparent" name="save" value="Update" >
                            <input type="hidden" name="actions" value="Update_Users">
                        </div>
                      </form>
                    </div><!-- End OF card body -->
                </div><!-- End OF card -->
                    </div><!-- End of form group -->
            </div><!-- End of col -->
            
            </div>
        </div><!-- End of row -->

    </div> <!-- End OF Content -->






<!-- link Jquery  -->
<script src="../js/jquery-3.4.1.min.js" ></script>
<!-- Java script  -->
<script src="../js/bootstrap.bundle.js" ></script>
<!-- jquery.ripples -->
<script src="../js/jquery.ripples-min.js" ></script>
<!-- magnific popup -->
<script src="../js/jquery.magnific-popup.js" ></script>
<!-- script.js -->
<script src="../js/script.js" ></script>
</body>
</html>